﻿namespace Warehouse
{
    partial class Interface
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            label26 = new Label();
            label25 = new Label();
            label24 = new Label();
            label23 = new Label();
            label22 = new Label();
            label16 = new Label();
            textBox5 = new TextBox();
            textBox4 = new TextBox();
            textBox3 = new TextBox();
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            tabPage2 = new TabPage();
            label31 = new Label();
            label30 = new Label();
            label29 = new Label();
            label28 = new Label();
            label27 = new Label();
            label18 = new Label();
            textBox10 = new TextBox();
            textBox9 = new TextBox();
            textBox8 = new TextBox();
            textBox7 = new TextBox();
            textBox6 = new TextBox();
            label10 = new Label();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            tabPage3 = new TabPage();
            label36 = new Label();
            label35 = new Label();
            label34 = new Label();
            label33 = new Label();
            label32 = new Label();
            label20 = new Label();
            textBox15 = new TextBox();
            textBox14 = new TextBox();
            textBox13 = new TextBox();
            textBox12 = new TextBox();
            textBox11 = new TextBox();
            label15 = new Label();
            label14 = new Label();
            label13 = new Label();
            label12 = new Label();
            label11 = new Label();
            button1 = new Button();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            tabPage2.SuspendLayout();
            tabPage3.SuspendLayout();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Controls.Add(tabPage3);
            tabControl1.Location = new Point(12, 12);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(312, 264);
            tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(label26);
            tabPage1.Controls.Add(label25);
            tabPage1.Controls.Add(label24);
            tabPage1.Controls.Add(label23);
            tabPage1.Controls.Add(label22);
            tabPage1.Controls.Add(label16);
            tabPage1.Controls.Add(textBox5);
            tabPage1.Controls.Add(textBox4);
            tabPage1.Controls.Add(textBox3);
            tabPage1.Controls.Add(textBox2);
            tabPage1.Controls.Add(textBox1);
            tabPage1.Controls.Add(label5);
            tabPage1.Controls.Add(label4);
            tabPage1.Controls.Add(label3);
            tabPage1.Controls.Add(label2);
            tabPage1.Controls.Add(label1);
            tabPage1.Location = new Point(4, 24);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(304, 236);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Sand";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // label26
            // 
            label26.AutoSize = true;
            label26.Location = new Point(221, 197);
            label26.Name = "label26";
            label26.Size = new Size(59, 15);
            label26.TabIndex = 16;
            label26.Text = "1500 / M3";
            // 
            // label25
            // 
            label25.AutoSize = true;
            label25.Location = new Point(221, 161);
            label25.Name = "label25";
            label25.Size = new Size(59, 15);
            label25.TabIndex = 15;
            label25.Text = "1500 / M3";
            // 
            // label24
            // 
            label24.AutoSize = true;
            label24.Location = new Point(220, 122);
            label24.Name = "label24";
            label24.Size = new Size(59, 15);
            label24.TabIndex = 14;
            label24.Text = "1500 / M3";
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Location = new Point(220, 86);
            label23.Name = "label23";
            label23.Size = new Size(59, 15);
            label23.TabIndex = 13;
            label23.Text = "1500 / M3";
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Location = new Point(220, 54);
            label22.Name = "label22";
            label22.Size = new Size(59, 15);
            label22.TabIndex = 12;
            label22.Text = "1500 / M3";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label16.Location = new Point(7, 14);
            label16.Name = "label16";
            label16.Size = new Size(96, 19);
            label16.TabIndex = 10;
            label16.Text = "Type of Sand";
            // 
            // textBox5
            // 
            textBox5.Location = new Point(115, 198);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(100, 23);
            textBox5.TabIndex = 9;
            // 
            // textBox4
            // 
            textBox4.Location = new Point(115, 167);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(100, 23);
            textBox4.TabIndex = 8;
            // 
            // textBox3
            // 
            textBox3.Location = new Point(115, 133);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(100, 23);
            textBox3.TabIndex = 7;
            // 
            // textBox2
            // 
            textBox2.Location = new Point(115, 101);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(100, 23);
            textBox2.TabIndex = 6;
            // 
            // textBox1
            // 
            textBox1.Location = new Point(115, 61);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(100, 23);
            textBox1.TabIndex = 5;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(19, 206);
            label5.Name = "label5";
            label5.Size = new Size(82, 15);
            label5.TabIndex = 4;
            label5.Text = "Masonry Sand";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(18, 175);
            label4.Name = "label4";
            label4.Size = new Size(85, 15);
            label4.TabIndex = 3;
            label4.Text = "Industrial Sand";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(19, 141);
            label3.Name = "label3";
            label3.Size = new Size(51, 15);
            label3.TabIndex = 2;
            label3.Text = "Fill Sand";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(19, 109);
            label2.Name = "label2";
            label2.Size = new Size(84, 15);
            label2.TabIndex = 1;
            label2.Text = "Concrete Sand";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(19, 69);
            label1.Name = "label1";
            label1.Size = new Size(67, 15);
            label1.TabIndex = 0;
            label1.Text = "Utility Sand";
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(label31);
            tabPage2.Controls.Add(label30);
            tabPage2.Controls.Add(label29);
            tabPage2.Controls.Add(label28);
            tabPage2.Controls.Add(label27);
            tabPage2.Controls.Add(label18);
            tabPage2.Controls.Add(textBox10);
            tabPage2.Controls.Add(textBox9);
            tabPage2.Controls.Add(textBox8);
            tabPage2.Controls.Add(textBox7);
            tabPage2.Controls.Add(textBox6);
            tabPage2.Controls.Add(label10);
            tabPage2.Controls.Add(label9);
            tabPage2.Controls.Add(label8);
            tabPage2.Controls.Add(label7);
            tabPage2.Controls.Add(label6);
            tabPage2.Location = new Point(4, 24);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(304, 236);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Wood";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // label31
            // 
            label31.AutoSize = true;
            label31.Location = new Point(226, 207);
            label31.Name = "label31";
            label31.Size = new Size(56, 15);
            label31.TabIndex = 16;
            label31.Text = "400 / Log";
            // 
            // label30
            // 
            label30.AutoSize = true;
            label30.Location = new Point(226, 173);
            label30.Name = "label30";
            label30.Size = new Size(56, 15);
            label30.TabIndex = 15;
            label30.Text = "370 / Log";
            // 
            // label29
            // 
            label29.AutoSize = true;
            label29.Location = new Point(226, 135);
            label29.Name = "label29";
            label29.Size = new Size(56, 15);
            label29.TabIndex = 14;
            label29.Text = "280 / Log";
            // 
            // label28
            // 
            label28.AutoSize = true;
            label28.Location = new Point(225, 101);
            label28.Name = "label28";
            label28.Size = new Size(56, 15);
            label28.TabIndex = 13;
            label28.Text = "250 / Log";
            // 
            // label27
            // 
            label27.AutoSize = true;
            label27.Location = new Point(225, 68);
            label27.Name = "label27";
            label27.Size = new Size(56, 15);
            label27.TabIndex = 12;
            label27.Text = "350 / Log";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point);
            label18.Location = new Point(6, 13);
            label18.Name = "label18";
            label18.Size = new Size(95, 17);
            label18.TabIndex = 10;
            label18.Text = "Type of Wood";
            // 
            // textBox10
            // 
            textBox10.Location = new Point(125, 199);
            textBox10.Name = "textBox10";
            textBox10.Size = new Size(95, 23);
            textBox10.TabIndex = 9;
            // 
            // textBox9
            // 
            textBox9.Location = new Point(125, 165);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(95, 23);
            textBox9.TabIndex = 8;
            // 
            // textBox8
            // 
            textBox8.Location = new Point(125, 127);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(95, 23);
            textBox8.TabIndex = 7;
            // 
            // textBox7
            // 
            textBox7.Location = new Point(124, 93);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(95, 23);
            textBox7.TabIndex = 6;
            // 
            // textBox6
            // 
            textBox6.Location = new Point(124, 60);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(95, 23);
            textBox6.TabIndex = 5;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(19, 207);
            label10.Name = "label10";
            label10.Size = new Size(65, 15);
            label10.TabIndex = 4;
            label10.Text = "Pine Wood";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(19, 173);
            label9.Name = "label9";
            label9.Size = new Size(75, 15);
            label9.TabIndex = 3;
            label9.Text = "Maple Wood";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(19, 135);
            label8.Name = "label8";
            label8.Size = new Size(80, 15);
            label8.TabIndex = 2;
            label8.Text = "Walnut Wood";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(19, 101);
            label7.Name = "label7";
            label7.Size = new Size(99, 15);
            label7.TabIndex = 1;
            label7.Text = "Mahogany Wood";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(21, 68);
            label6.Name = "label6";
            label6.Size = new Size(63, 15);
            label6.TabIndex = 0;
            label6.Text = "Oak Wood";
            // 
            // tabPage3
            // 
            tabPage3.Controls.Add(label36);
            tabPage3.Controls.Add(label35);
            tabPage3.Controls.Add(label34);
            tabPage3.Controls.Add(label33);
            tabPage3.Controls.Add(label32);
            tabPage3.Controls.Add(label20);
            tabPage3.Controls.Add(textBox15);
            tabPage3.Controls.Add(textBox14);
            tabPage3.Controls.Add(textBox13);
            tabPage3.Controls.Add(textBox12);
            tabPage3.Controls.Add(textBox11);
            tabPage3.Controls.Add(label15);
            tabPage3.Controls.Add(label14);
            tabPage3.Controls.Add(label13);
            tabPage3.Controls.Add(label12);
            tabPage3.Controls.Add(label11);
            tabPage3.Location = new Point(4, 24);
            tabPage3.Name = "tabPage3";
            tabPage3.Padding = new Padding(3);
            tabPage3.Size = new Size(304, 236);
            tabPage3.TabIndex = 2;
            tabPage3.Text = "Steel";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // label36
            // 
            label36.AutoSize = true;
            label36.Location = new Point(222, 204);
            label36.Name = "label36";
            label36.Size = new Size(65, 15);
            label36.TabIndex = 16;
            label36.Text = "3500 / 10m";
            // 
            // label35
            // 
            label35.AutoSize = true;
            label35.Location = new Point(222, 166);
            label35.Name = "label35";
            label35.Size = new Size(65, 15);
            label35.TabIndex = 15;
            label35.Text = "3000 / 10m";
            // 
            // label34
            // 
            label34.AutoSize = true;
            label34.Location = new Point(222, 133);
            label34.Name = "label34";
            label34.Size = new Size(65, 15);
            label34.TabIndex = 14;
            label34.Text = "3200 / 10m";
            // 
            // label33
            // 
            label33.AutoSize = true;
            label33.Location = new Point(222, 99);
            label33.Name = "label33";
            label33.Size = new Size(65, 15);
            label33.TabIndex = 13;
            label33.Text = "2700 / 10m";
            // 
            // label32
            // 
            label32.AutoSize = true;
            label32.Location = new Point(222, 67);
            label32.Name = "label32";
            label32.Size = new Size(65, 15);
            label32.TabIndex = 12;
            label32.Text = "2400 / 10m";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Font = new Font("Segoe UI", 10F, FontStyle.Bold, GraphicsUnit.Point);
            label20.Location = new Point(6, 13);
            label20.Name = "label20";
            label20.Size = new Size(96, 19);
            label20.TabIndex = 10;
            label20.Text = "Type of Steel";
            // 
            // textBox15
            // 
            textBox15.Location = new Point(133, 196);
            textBox15.Name = "textBox15";
            textBox15.Size = new Size(83, 23);
            textBox15.TabIndex = 9;
            // 
            // textBox14
            // 
            textBox14.Location = new Point(133, 158);
            textBox14.Name = "textBox14";
            textBox14.Size = new Size(83, 23);
            textBox14.TabIndex = 8;
            // 
            // textBox13
            // 
            textBox13.Location = new Point(133, 125);
            textBox13.Name = "textBox13";
            textBox13.Size = new Size(83, 23);
            textBox13.TabIndex = 7;
            // 
            // textBox12
            // 
            textBox12.Location = new Point(133, 91);
            textBox12.Name = "textBox12";
            textBox12.Size = new Size(83, 23);
            textBox12.TabIndex = 6;
            // 
            // textBox11
            // 
            textBox11.Location = new Point(133, 59);
            textBox11.Name = "textBox11";
            textBox11.Size = new Size(83, 23);
            textBox11.TabIndex = 5;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(19, 204);
            label15.Name = "label15";
            label15.Size = new Size(82, 15);
            label15.TabIndex = 4;
            label15.Text = "Titanium Steel";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(19, 166);
            label14.Name = "label14";
            label14.Size = new Size(80, 15);
            label14.TabIndex = 3;
            label14.Text = "Stainless Steel";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(19, 133);
            label13.Name = "label13";
            label13.Size = new Size(62, 15);
            label13.TabIndex = 2;
            label13.Text = "Alloy Steel";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(19, 99);
            label12.Name = "label12";
            label12.Size = new Size(74, 15);
            label12.TabIndex = 1;
            label12.Text = "Carbon Steel";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(19, 67);
            label11.Name = "label11";
            label11.Size = new Size(57, 15);
            label11.TabIndex = 0;
            label11.Text = "Raw Steel";
            // 
            // button1
            // 
            button1.Location = new Point(130, 289);
            button1.Name = "button1";
            button1.Size = new Size(75, 23);
            button1.TabIndex = 1;
            button1.Text = "Calculate";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // Interface
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(337, 330);
            Controls.Add(button1);
            Controls.Add(tabControl1);
            Name = "Interface";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Interface";
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            tabPage3.ResumeLayout(false);
            tabPage3.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private TextBox textBox5;
        private TextBox textBox4;
        private TextBox textBox3;
        private TextBox textBox2;
        private TextBox textBox1;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TextBox textBox10;
        private TextBox textBox9;
        private TextBox textBox8;
        private TextBox textBox7;
        private TextBox textBox6;
        private Label label10;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private TabPage tabPage3;
        private TextBox textBox15;
        private TextBox textBox14;
        private TextBox textBox13;
        private TextBox textBox12;
        private TextBox textBox11;
        private Label label15;
        private Label label14;
        private Label label13;
        private Label label12;
        private Label label11;
        private Label label16;
        private Label label18;
        private Label label20;
        private Label label26;
        private Label label25;
        private Label label24;
        private Label label23;
        private Label label22;
        private Label label30;
        private Label label29;
        private Label label28;
        private Label label27;
        private Label label31;
        private Label label36;
        private Label label35;
        private Label label34;
        private Label label33;
        private Label label32;
        private Button button1;
    }
}